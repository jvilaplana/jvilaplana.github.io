#!/bin/bash
helloWorld
function helloWorld {
  echo "Hello world"
}
helloWorld
exit 0
