#!/bin/bash
n=0
n=$((n+=2))
echo "n<<2 equals to $((n<<2))"   # 2 bits displacement to the left (*4)
a=66 b=600
echo "a + b equals to $((a+b))"
