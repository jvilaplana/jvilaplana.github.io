#!/bin/bash
myname=Arya
echo myname
echo $myname
myname="Arya       Stark"
echo $myname
echo "$myname"
echo '$myname'
