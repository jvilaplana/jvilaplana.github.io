#!/bin/bash
echo "Script [START]"
name="Illidan Stormrage"
sentence="You are not prepared!"

wall << endOfMessage
.------------------------------------------------.
| $name yells: $sentence |
·------------------------------------------------·
endOfMessage

echo "Script [END]"
exit 0
