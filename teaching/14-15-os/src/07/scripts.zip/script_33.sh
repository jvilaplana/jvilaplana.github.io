#!/bin/bash
find . -name 'script*'
echo "------------------"
find $HOME -name '*.sh' -print
exit 0
