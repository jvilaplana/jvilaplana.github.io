#!/bin/bash
name=Arya
echo $name
unset name
echo $name
name=Stark
echo $name
name=
echo $name
set
