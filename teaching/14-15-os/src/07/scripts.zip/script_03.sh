#!/bin/bash
touch data1
touch data2
files=data*
echo $files
echo "$files"
num=666
echo $num
declare -i x=999
echo $x
x="nine"
echo $x
