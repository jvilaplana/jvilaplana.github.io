#!/bin/bash
echo "Write your name and surname: "
read name surname
echo "Your name is $name $surname"
