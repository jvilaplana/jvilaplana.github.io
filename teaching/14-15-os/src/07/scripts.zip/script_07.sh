#!/bin/bash
echo "Script $0 started"
exec date
echo "Script $0 finished"       # This line will not be executed
