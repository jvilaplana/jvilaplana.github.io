#!/bin/bash
set hell to highway $(date)
echo $3 $2 $1
echo $@
